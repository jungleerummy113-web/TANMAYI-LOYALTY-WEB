# TANMAYI STORE AND GIFTS — Render PIN Reset package

This package moves only the PIN-reset server endpoints to Render. It does not replace the Firebase project, customer website data, Firestore rules, bills, stamps, rewards, or redemption history.

## What it does
- Admin endpoint verifies the Firebase ID token and `admins/{uid}` (`role: admin`, `active: true`).
- Admin issues a cryptographically random 8-digit one-time code.
- A newly issued code replaces the previous code for that customer.
- Code expires after 10 minutes and is single-use.
- Customer reset validates registered mobile + code + new 6-digit PIN.
- Only Firebase Authentication password is changed. Firestore customer profile and loyalty history are untouched.

## 1. Deploy the backend to Render
Create a **Web Service** from a private GitHub repository containing the `render-service` folder.
- Root Directory: `render-service`
- Runtime: Node
- Build Command: `npm install`
- Start Command: `npm start`

Add these Render Environment Variables:
- `FIREBASE_PROJECT_ID` = `tanmayi-store-and-gifts`
- `FIREBASE_SERVICE_ACCOUNT_JSON` = complete JSON content of a dedicated Firebase service-account key with the minimum needed Firebase Admin privileges.

Do not paste the service-account JSON into chat, GitHub, or this README. Add it only in Render's Environment settings. Keep the GitHub repository private. If possible, create a dedicated service account and grant only Firebase Authentication user management plus Firestore read/write access required by this service. Protect the key and rotate it if exposed.

After deploy, open `https://YOUR-RENDER-SERVICE.onrender.com/health`. It should return `{"ok":true,"service":"tanmayi-pin-reset"}`.

## 2. Connect the website
1. In `website-update/index.html`, find:
   `const PIN_RESET_API_BASE='https://YOUR-RENDER-SERVICE.onrender.com';`
2. Replace only the placeholder URL with the actual Render HTTPS URL.
3. Upload this updated `index.html` to the existing website hosting location, after taking a backup of the current file. Do not replace other website files.

The updated page adds:
- **Generate Reset Code** in the admin customer detail panel.
- **Forgot PIN? Reset with admin code** in the customer login panel.

## 3. Existing Firestore security rule
The existing deny rule for `/pinResetAuthorizations/{docId}` should remain:
`match /pinResetAuthorizations/{docId} { allow read, write: if false; }`
Do not replace the full Firestore ruleset.

## Important
- Render Free services can sleep when idle; the first request after sleep can take time. A paid always-on instance may be needed for a faster shop experience.
- The server requires a Firebase service-account credential. Never expose it in browser code or public repositories.
- Test with a non-critical test customer before live use.
- This package has not been deployed to your Render account and is not connected until you complete the environment setup and update the website URL.
